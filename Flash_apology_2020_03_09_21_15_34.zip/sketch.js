var r = 100;
var b = 255;
var g = 100;

var a = 0;
var b = 0;

let arr1 = [20];
let arr2 = [20];

var x = 160;
var x1 = 180;
var x2 = 140;
var z = 360;
var z1 = 380;
var z2 = 340;
var speed = 2;

var spot = {
  x: 100,
  y: 50
};
  
var col = {
  r: 255,
  g: 0,
  b: 0
};

function setup() {
  createCanvas(400, 400);
  strokeWeight(3);
} 

function mousePressed(){
  
print( mouseX +  "   " + mouseY);
  
}

function randomXY() {
  for (var i = 0; i < 20; i++) {
   fill(255,255,255)
    ellipse ( arr1[i], arr2[i],7,7);
    arr1[i] = random(0, 400)
    arr2[i] = random(0, 400)
    
  }
}

function draw() {
 
  r = map(mouseY, 0, 600, 5, 0);                //day-night
  b = map(mouseY, 0, 600, 255, 0);
  g = map(mouseY, 0, 600, 180, 0);
  background(r, g, b);
  

  //Sun
  r = map(mouseY, 200, 400, 205, 0);
  b = map(mouseY, 200, 400, 25, 0);
  fill(255, 234, 0);
  ellipse(90, mouseY, 60, 60);
  
  if (mouseY>200){
    randomXY();
  }
  //print (r, g, b);
  
  fill (250);
  //noStroke();
  ellipse(x, 100, 75, 35);
  ellipse(x1, 115, 80, 30);
  ellipse(x2, 115, 80, 30);
  
  ellipse(z, 90, 60, 45);
  ellipse(z1, 100, 80, 40);
  ellipse(z2, 100, 80, 35);
	
  if (x > width) {
    speed =  -2;
  }
  x = x + speed;
  x1 = x1 + speed;
  x2 = x2 + speed;
  
  if (z > width) {
    speed = -1;
  }
  z = z + speed;
  z1 = z1 + speed;
  z2 = z2 + speed;
 
  if (x<0){
    speed = 1;
  }
  // col.r = random(0, 250);
  // col.g = random(0, 255);
  // col.b = random(100, 255);
  // spot.x = random(0, width);
  // spot.y = random(0, height/2);
  // fill(col.r, col.g, col.b, 55);
  // //noStroke();
  // fill(255,255,255)
  // ellipse(spot.x, spot.y, 7, 7);

//   background(0, 136, 255);
  
  //fill(255, 251, 0);
 // ellipse(331,45, 60, 60);


  
   fill(8, 209, 89)
   rect(0,200 ,399,200)             //grass
  
   fill(82, 77, 77)                 //road to house
  rect(155,210,80,220)
  
  fill(255,0,0)
   rect(90, 120, 200, 200);        //house
  
  fill(255,255,255)
  triangle ( 90, 120, 190, 30, 290,120 );
 
  fill(238,255,0)
  rect(165, 210, 60, 110);          //door
  
  fill(20, 2, 2)
  ellipse(212,264, 5, 5)
  
 //   fill(82, 77, 77)
 //   rect(155,210,80,220)
  

  fill(0,0,255)
  ellipse(195 ,170, 50,30); 
  fill(255,255,255)
   line (195,158,195,185)
  fill(255,255,255)
 line(171,171,219,171)
  
  
   fill(0,0,255)
  ellipse(130 ,250, 40,30);
  fill(255,255,255)
  line(110,251,149,251)
  fill(255,255,255)
  line(130,237,130,264)
  fill(238,0,255)

   fill(0,0,255)
   ellipse(260 ,250, 40,30);
   fill(255,255,255)
   line(260,237,260,264)
   line(241,249,280,249)
}