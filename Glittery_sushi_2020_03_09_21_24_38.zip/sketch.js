let index = 0; //  for function 8
let x1 = 0;
let x2 = 500;
let x3 = 1000;
let x4 = 1500;
let x5 = 2000;
let x6 = 2500;

function preload() {
  image1 = loadImage('1.jpg.jpg');
  image2 = loadImage('2.jpg.jpg');
  image3 = loadImage('3.jpg.jpg');
  image4 = loadImage('4.jpg.jpg');
  image5 = loadImage('5.jpg.jpg');
  image6 = loadImage('6.jpg.jpg');
}

function setup() {
  createCanvas(500, 500);

  test = new Platform(image1, image2, image3, image4, image5, image6);
}

function draw() {
  background(222);

  test.function9();
}

class Platform {
  constructor() {
    this.x = 0;     // offset position that will affect all the images
    this.speed = 3.32; // how fast you want something to move, depends on your implementation  // used for function6

    this.arr = [image1, image2, image3, image4, image5, image6];
    print("Length is: " + this.arr.length);
  }

  // Format: image(this.array[index], x, y, width, height);


  // scroll with user control of 
  function6() {

    this.x = mouseX * this.speed;
    image(this.arr[0], 0 - this.x, 0, width, height);
    image(this.arr[1], 500 - this.x, 0, width, height);
    image(this.arr[2], 1000 - this.x, 0, width, height);
    image(this.arr[3], 1500 - this.x, 0, width, height);
    image(this.arr[4], 2000 - this.x, 0, width, height);
    image(this.arr[5], 2500 - this.x, 0, width, height);



  }
  // scroll up and down
  function7() {
    
    
    // this.x = mouseY * this.speed; // in order to use the mouseX position instead of mouseY because it fully shows, need to figure out a different speed for 
    this.x = mouseX * this.speed;
    image(this.arr[0], 0, 0 - this.x, width, height);
    image(this.arr[1], 0, 500 - this.x, width, height);
    image(this.arr[2], 0, 1000 - this.x, width, height);
    image(this.arr[3], 0, 1500 - this.x, width, height);
    image(this.arr[4], 0, 2000 - this.x, width, height);
    image(this.arr[5], 0, 2500 - this.x, width, height);



  }
  // scroll to the left without user control
  function8() {
    
    image(this.arr[0], x1, 0, width, height);
    image(this.arr[1], x2, 0, width, height);
    image(this.arr[2], x3 , 0, width, height);
    image(this.arr[3], x4 , 0, width, height);
    image(this.arr[4], x5 , 0, width, height);
    image(this.arr[5], x6 , 0, width, height);
    
    x1 -= this.speed;
    x2 -= this.speed;
    x3 -= this.speed;
    x4 -= this.speed;
    x5 -= this.speed;
    x6 -= this.speed;
    
    if (x1 < -2500) {
      x1 = width;
    }
    if (x2 < -2500) {
      x2 = width;
    }
    if (x3 < -2500) {
      x3 = width;
    }
    if (x4 < -2500) {
      x4 = width;
    }
    if (x5 < -2500) {
      x5 = width;
    }
    if (x6 < -2500) {
      x6 = width;
    }

  }

  // click image, image will change
  function9() {

    image(this.arr[index], 0, 0, width, height);
  }
}

// for function9 currently
function mousePressed() {
  // for function9
  index++;

  // reset the index
  if (index > 5) {
    index = 0;
  }
}